Compiles with Visual Studio 2015
Tested with Matlab 2019b
Tested with PLCSIM Advanced v3.0

Erzeugen der MEX-Datei:

- �ffnen Sie MATLAB
- Navigieren Sie zu dem Ordner
- F�hren Sie im Command Window "run build.m" aus
- Nach erfolgreicher Durchf�hrung:
- �ffnen Sie die Bibliothek "PLCSIMAdvancedBlockLibrary.slx"
- Starten Sie Simulink
- Erstellen Sie ein Simulink Modell
- Zihen Sie den Block PLCSIMAdvanced aus der Bibliothek in das neue Modell


Build the MEX file:

- open MATLAB
- go to the folder
- in command window, do "run build.m"
- if build is ok:
- do "open PLCSIMAdvancedBlockLibrary.slx"
- Starting Simulink 
- Create a model in Simulink
- drag the PLCSIMAdvanced Block from the Block Library to the new model


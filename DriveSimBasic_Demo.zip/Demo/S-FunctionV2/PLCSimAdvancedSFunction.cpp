/**********************************************************************/
/*    Copyright (c) SIEMENS AG 2015, 2016, 2017                       */
/*    All Rights reserved.                                            */
/**********************************************************************/
/*    Project               Emulation of Automation Components		  */
/*                                                                    */
/*    Component             PLCSimAdvancedSFunction                   */
/*                                                                    */
/*    Module name           -                                         */
/*                                                                    */
/*    Version               V2.1                                      */
/*                                                                    */
/*    Date                  2018-11-27                                */
/*                                                                    */
/*    Author                SIEMENS						              */
/*                                                                    */
/**********************************************************************/
/*                                                                    */
/*    Description:          S7-PLCSIM Advanced S-Function for         */
/*                          MATLAB/Simulink                           */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <io.h>
#include <vector>
#include <string>

#ifdef _WIN32
#include <windows.h>
#include <TlHelp32.h>
#else
#error PLCSimAdvancedSFunction requires Microsoft Windows
#endif

#define S_FUNCTION_NAME PLCSimAdvancedSFunction
#define S_FUNCTION_LEVEL 2
#define MDL_START
#include "simstruc.h"

static const char_T * BlockPath = 0;

#define GetMessageSource()	(BlockPath != 0 ? BlockPath : "[PLCSIM Advanced S-Function]")

#define PrintFormattedMessage(F,...)		ssPrintf("%s: " F, GetMessageSource(), __VA_ARGS__)
#define PrintFormattedError(F,...)			ssPrintf("%s: Error: " F, GetMessageSource(), __VA_ARGS__)
#define PrintFormattedPLCSimError(F,...)	ssPrintf("%s: Error %ls (%d): " F, GetMessageSource(), GetNameOfErrorCode(srec), srec, __VA_ARGS__)

#include "SimulationRuntimeApi.h"

/*** Global Defines ***/

#define SyncWithSemaphore	0
#define SyncWithFlag		0
#define SyncWithCallback	(SyncWithSemaphore || SyncWithFlag)
#define SyncWithEvent		1

#define ShutdownWhenTerminating		1
#define ExecuteRunNextCycleLoop		1

#define MAX_INPUTS			1024
#define MAX_OUTPUTS			1024
#define MAX_IO_PORT_SIZE	64

/*** Global Variables ***/

static ISimulationRuntimeManager	*RuntimeManager = 0;
static IRemoteRuntimeManager		*RemoteRuntimeManager = 0;
static IInstance					*PLCSimInstance = 0;
static enum ERuntimeErrorCode		srec;

static BYTE IOBuffer[MAX_IO_PORT_SIZE];

#if SyncWithSemaphore
static HANDLE Semaphore = 0;
#endif
#if SyncWithFlag
static bool waiting;
#endif

/* Reference time to be mapped to time 0.0 in Simulink */
static SYSTEMTIME basePLCSimTime =
{
  2000,	// WORD wYear;
  1,	// WORD wMonth;
  0,	// WORD wDayOfWeek;
  1,	// WORD wDay;
  0,	// WORD wHour;
  0,	// WORD wMinute;
  0,	// WORD wSecond;
  0		// WORD wMilliseconds;
};

/* Simulink Block Parameters */

static const int ParameterCount = 12;

static int ParameterIndex_InstanceName = 0;
static int ParameterIndex_InputPortCount = 1;
static int ParameterIndex_OutputPortCount = 2;
static int ParameterIndex_ScaleFactor = 3;
static int ParameterIndex_Synchronization = 4;
static int ParameterIndex_Networking = 5;
static int ParameterIndex_IP = 6;
static int ParameterIndex_Port = 7;
static int ParameterIndex_OutputVariables = 8;
static int ParameterIndex_InputVariables = 9;
static int ParameterIndex_PIP = 10;
static int ParameterIndex_SampleTime = 11;

static const int	maxInstanceNameLength = 255;
static char_T		InstanceName[maxInstanceNameLength + 1];
static wchar_t		InstanceNameWS[maxInstanceNameLength + 1];
static int			InputPortCount = -1;
static int			OutputPortCount = -1;
static double		ScaleFactor = 1;
static bool			Synchronization = true;
static bool			Networking = true;
static const int	maxIPLength = 15;
static char_T		StringIP[maxIPLength + 1];
static UIP			IP;
static UINT16		Port = 0;
static const int	maxVariablesLength = 512;
static char_T		StringOutputVariables[maxVariablesLength + 1];
static int			outputVariableCounter = 0;
static std::vector<std::string> outputVariables;
static char_T		StringInputVariables[maxVariablesLength + 1];
static int			inputVariableCounter = 0;
static std::vector<std::string> inputVariables;
static SDataValueByName outputDataValueByName[MAX_OUTPUTS];
static SDataValue	outputDataValue;
static UDataValue	outputValue;
static SDataValueByName inputDataValueByName[MAX_INPUTS];
static SDataValue	inputDataValue;
static UDataValue	inputValue;
static int			pip;
static double		sampleTime;

/*** Utility Functions  ***/

class PLCTagTable {
private:
	STagInfo m_inout_TagInfos[64];

	size_t m_NumInputTags;
	size_t m_NumOutputTags;
	size_t m_NumDatablockOutputTags;
	size_t m_NumDatablockInputTags;
	unsigned int m_InputTagMap[MAX_INPUTS];
	unsigned int m_OutputTagMap[MAX_OUTPUTS];
	unsigned int m_DatablockInputTagMap[MAX_OUTPUTS];
	unsigned int m_DatablockOutputTagMap[MAX_OUTPUTS];
	bool m_TagMapValid;

public:
	PLCTagTable() {
		m_NumInputTags = 0;
		m_NumOutputTags = 0;
		m_NumDatablockOutputTags = 0;
		m_NumDatablockInputTags = 0;
		m_TagMapValid = false;
	};
	~PLCTagTable() {};

	/* Update local tag map with information from PLCSIM Advanced */
	void UpdateTagMap(IInstance * PLCSimInstance) {
		if (PLCSimInstance == 0) {
			PrintFormattedError("PLCTagTable: PLCSimInstance == 0.\n");
			return;
		}
		if (m_TagMapValid) {
			PrintFormattedMessage("PLCTagTable: TagMapIsUpToDate.\n");
			return;
		}

		//look for necessary DBs from variables parameter
		std::wstring db_filter;
		std::vector<std::wstring> db_filter_vector;

		for (int i = 0; i < outputVariables.size(); i++) {
			std::string db = outputVariables.at(i).substr(0, outputVariables.at(i).find("."));
			std::wstring wdb(db.begin(), db.end());

			bool contains = false;

			for (int j = 0; j < db_filter_vector.size(); j++) {
				if (db_filter_vector.at(j).compare(wdb) == 0) {
					contains = true;
					break;
				}
			}
			//put db filter string together
			if (contains == false) {
				if (db_filter_vector.size() != 0)
				{
					db_filter = db_filter + L",";
				}
				db_filter_vector.push_back(wdb);
				db_filter = db_filter + L"\"" + wdb + L"\"";
			}
		}

		for (int i = 0; i < inputVariables.size(); i++) {
			std::string db = inputVariables.at(i).substr(0, inputVariables.at(i).find("."));
			std::wstring wdb(db.begin(), db.end());

			bool contains = false;

			for (int j = 0; j < db_filter_vector.size(); j++) {
				if (db_filter_vector.at(j).compare(wdb) == 0) {
					contains = true;
					break;
				}
			}
			//put db filter string together
			if (contains == false) {
				if (db_filter_vector.size() != 0)
				{
					db_filter = db_filter + L",";
				}
				db_filter_vector.push_back(wdb);
				db_filter = db_filter + L"\"" + wdb + L"\"";
			}
		}


		enum ERuntimeErrorCode srec;

		//empty filter
		if (db_filter.size() < 3) {
			srec = PLCSimInstance->UpdateTagList(SRTLD_IO, false);
		}
		else {
			srec = PLCSimInstance->UpdateTagList(SRTLD_IODB, false, (WCHAR *)db_filter.c_str());
		}
		if (srec == SREC_WARNING_ALREADY_EXISTS)
		{
			PrintFormattedMessage("PLCTagTable: Updating tags from PLCSIM Advanced: configuration unchanged since last update.\n");
		}
		else if (srec != SREC_OK) {
			PrintFormattedPLCSimError("PLCTagTable: Error while updating tags from PLCSIM Advanced.\n");
		}

		m_NumInputTags = 0;
		m_NumOutputTags = 0;
		m_NumDatablockOutputTags = 0;
		m_NumDatablockInputTags = 0;

		UINT32 tagInfoCount = PLCSimInstance->GetTagInfoCount();
		UINT32 outTagInfoCount;

		PrintFormattedMessage("PLCTagTable: Reading tags from PLCSIM Advanced: found a total of %d tags.\n", tagInfoCount);

		PLCSimInstance->GetTagInfos(sizeof(m_inout_TagInfos), m_inout_TagInfos, &outTagInfoCount);
		if (tagInfoCount != outTagInfoCount) {
			PrintFormattedError("PLCTagTable: Error: expected %d tags, but GetTagInfos returned only %d.\n", tagInfoCount, outTagInfoCount);
			return;
		}
		for (UINT32 i = 0; i < outTagInfoCount; ++i)
		{
			if (m_inout_TagInfos[i].Area == SRA_INPUT && m_NumInputTags < MAX_INPUTS)
			{
				m_InputTagMap[m_NumInputTags++] = i;
				PrintFormattedMessage("PLCTagTable: Input %d: %ls\n", m_NumInputTags, m_inout_TagInfos[i].Name);
			}
			if (m_inout_TagInfos[i].Area == SRA_OUTPUT && m_NumOutputTags < MAX_OUTPUTS)
			{
				m_OutputTagMap[m_NumOutputTags++] = i;
				PrintFormattedMessage("PLCTagTable: Output %d: %ls\n", m_NumOutputTags, m_inout_TagInfos[i].Name);
			}
		}
		for (int j = 0; j < outputVariables.size(); j++) {

			for (UINT32 i = 0; i < outTagInfoCount; ++i) {

				if (m_inout_TagInfos[i].Area == SRA_DATABLOCK && m_NumDatablockOutputTags < MAX_OUTPUTS)
				{
					bool match = false;

					std::wstring wstr1(outputVariables.at(j).begin(), outputVariables.at(j).end());
					std::wstring wstr2(m_inout_TagInfos[i].Name);
					if (wstr2.compare(wstr1) == 0) {
						wcscpy(outputDataValueByName[m_NumDatablockOutputTags].Name, m_inout_TagInfos[i].Name);

						m_DatablockOutputTagMap[m_NumDatablockOutputTags++] = i;
						PrintFormattedMessage("PLCTagTable: DATABLOCK %d: %ls\n", m_NumDatablockOutputTags, m_inout_TagInfos[i].Name);
					}
					else {
						//PrintFormattedMessage("PLCTagTable: DATABLOCK %d: did not match\n", m_NumDatablockOutputTags, m_inout_TagInfos[i].Name);
					}

				}
			}
		}

		for (int j = 0; j < inputVariables.size(); j++) {

			for (UINT32 i = 0; i < outTagInfoCount; ++i) {

				if (m_inout_TagInfos[i].Area == SRA_DATABLOCK && m_NumDatablockInputTags < MAX_INPUTS)
				{
					bool match = false;

					std::wstring wstr1(inputVariables.at(j).begin(), inputVariables.at(j).end());
					std::wstring wstr2(m_inout_TagInfos[i].Name);
					if (wstr2.compare(wstr1) == 0) {
						wcscpy(inputDataValueByName[m_NumDatablockInputTags].Name, m_inout_TagInfos[i].Name);

						m_DatablockInputTagMap[m_NumDatablockInputTags++] = i;
						PrintFormattedMessage("PLCTagTable: DATABLOCK %d: %ls\n", m_NumDatablockInputTags, m_inout_TagInfos[i].Name);
					}
					else {
						//PrintFormattedMessage("PLCTagTable: DATABLOCK %d: did not match\n", m_NumDatablockInputTags, m_inout_TagInfos[i].Name);
					}

				}
			}
		}

		PrintFormattedMessage("PLCTagTable: Updated tags: %d inputs, %d outputs, %d datablockinputs,%d datablockoutputs\n", m_NumInputTags, m_NumOutputTags, m_NumDatablockInputTags, m_NumDatablockOutputTags);
		m_TagMapValid = true;
	}

	void invalidate() {
		m_TagMapValid = false;
	}

	bool TagMapValid() {
		return m_TagMapValid;
	}

	BuiltInDTypeId GetSimulinkDataType(EDataType type)
	{
		switch (type)
		{
		case SRDT_UNKNOWN:
			return SS_DOUBLE;
		case SRDT_STRUCT:
			return SS_INT32;
		case SRDT_BOOL:
			return SS_BOOLEAN;
		case SRDT_SINT:
			return SS_INT8;
		case SRDT_INT:
			return SS_INT16;
		case SRDT_DINT:
			return SS_INT32;
		case SRDT_LINT:
			return SS_INT32;
		case SRDT_USINT:
			return SS_UINT8;
		case SRDT_UINT:
			return SS_UINT16;
		case SRDT_UDINT:
			return SS_UINT32;
		case SRDT_ULINT:
			return SS_UINT32;
		case SRDT_REAL:
			return SS_SINGLE;
		case SRDT_LREAL:
			return SS_DOUBLE;
		case SRDT_CHAR:
			return SS_UINT8;
		case SRDT_WCHAR:
			return SS_UINT16;
		default:
			return SS_DOUBLE;
		}
	}

	void debug_input(int index) {
		PrintFormattedMessage("PLCTagTable: debug_input %d: plctag %d, %ls %ls\n", index, m_InputTagMap[index], GetNameOfDataType(m_inout_TagInfos[m_InputTagMap[index]].DataType), m_inout_TagInfos[m_InputTagMap[index]].Name);
	}
	void debug_output(int index) {
		PrintFormattedMessage("PLCTagTable: debug_output %d: plctag %d, %ls %ls\n", index, m_OutputTagMap[index], GetNameOfDataType(m_inout_TagInfos[m_OutputTagMap[index]].DataType), m_inout_TagInfos[m_OutputTagMap[index]].Name);
	}

	BuiltInDTypeId InputSSDataType(size_t index) {
		return GetSimulinkDataType(m_inout_TagInfos[m_InputTagMap[index]].DataType);
	}
	EDataType InputDataType(size_t index) {
		return m_inout_TagInfos[m_InputTagMap[index]].DataType;
	}
	UINT16 InputSize(size_t index) {
		return m_inout_TagInfos[m_InputTagMap[index]].Size;
	}
	UINT32 InputOffset(size_t index) {
		return m_inout_TagInfos[m_InputTagMap[index]].Offset;
	}
	UINT8 InputBit(size_t index) {
		return m_inout_TagInfos[m_InputTagMap[index]].Bit;
	}

	BuiltInDTypeId OutputSSDataType(size_t index) {
		return GetSimulinkDataType(m_inout_TagInfos[m_OutputTagMap[index]].DataType);
	}

	BuiltInDTypeId DatablockInputSSDataType(size_t index) {
		return GetSimulinkDataType(m_inout_TagInfos[m_DatablockInputTagMap[index]].DataType);
	}
	EPrimitiveDataType DatablockInputPrimitiveDataType(size_t index) {
		return m_inout_TagInfos[m_DatablockInputTagMap[index]].PrimitiveDataType;
	}
	BuiltInDTypeId DatablockOutputSSDataType(size_t index) {
		return GetSimulinkDataType(m_inout_TagInfos[m_DatablockOutputTagMap[index]].DataType);
	}
	EDataType OutputDataType(size_t index) {
		return m_inout_TagInfos[m_OutputTagMap[index]].DataType;
	}
	UINT16 OutputSize(size_t index) {
		return m_inout_TagInfos[m_OutputTagMap[index]].Size;
	}
	UINT32 OutputOffset(size_t index) {
		return m_inout_TagInfos[m_OutputTagMap[index]].Offset;
	}
	UINT8 OutputBit(size_t index) {
		return m_inout_TagInfos[m_OutputTagMap[index]].Bit;
	}
	EArea OutputArea(size_t index) {
		if (index <= m_NumOutputTags)
		{
			return m_inout_TagInfos[m_OutputTagMap[index]].Area;
		}
		else {
			return EArea::SRA_INVALID_AREA;
		}
	}
	EArea InputArea(size_t index) {
		if (index <= m_NumInputTags)
		{
			return m_inout_TagInfos[m_InputTagMap[index]].Area;
		}
		else {
			return EArea::SRA_INVALID_AREA;
		}
	}
	EArea DatablockInputArea(size_t index) {
		if (index <= m_NumDatablockInputTags)
		{
			return m_inout_TagInfos[m_DatablockInputTagMap[index]].Area;
		}
		else {
			return EArea::SRA_INVALID_AREA;
		}
	}
	EArea DatablockOutputArea(size_t index) {
		if (index <= m_NumDatablockOutputTags)
		{
			return m_inout_TagInfos[m_DatablockOutputTagMap[index]].Area;
		}
		else {
			return EArea::SRA_INVALID_AREA;
		}
	}

	void OutputName(size_t index, WCHAR* outStr) {
		wcscpy(outStr, m_inout_TagInfos[m_OutputTagMap[index]].Name);
	}

	size_t NumInputTags() {
		return m_NumInputTags;
	}
	size_t NumOutputTags() {
		return m_NumOutputTags;
	}
	size_t NumDatablockOutputTags() {
		return m_NumDatablockOutputTags;
	}
	size_t NumDatablockInputTags() {
		return m_NumDatablockInputTags;
	}

	EPrimitiveDataType OutputPrimitiveDataType(size_t index) {
		return m_inout_TagInfos[m_OutputTagMap[index]].PrimitiveDataType;
	}
};

PLCTagTable tags;

/* Convert SYSTEMTIME to ULONGLONG (number of 100-nanosecond intervals since January 1, 1601 (UTC)) */
static ULONGLONG SystemTimeToULongLong(SYSTEMTIME s)
{
	FILETIME t;
	if (!SystemTimeToFileTime(&s, &t))
	{
		PrintFormattedError("Could not convert SYSTEMTIME to FILETIME (error code %d).\n", GetLastError());
		return 0;
	}
	ULARGE_INTEGER i;
	i.LowPart = t.dwLowDateTime;
	i.HighPart = t.dwHighDateTime;
	return i.QuadPart;
}

/* Convert ULONGLONG (number of 100-nanosecond intervals since January 1, 1601 (UTC)) to SYSTEMTIME */
static SYSTEMTIME ULongLongToSystemTime(ULONGLONG u)
{
	ULARGE_INTEGER i;
	i.QuadPart = u;
	FILETIME t;
	t.dwLowDateTime = i.LowPart;
	t.dwHighDateTime = i.HighPart;
	SYSTEMTIME s;
	if (!FileTimeToSystemTime(&t, &s))
	{
		PrintFormattedError("Could not convert FILETIME to SYSTEMTIME (error code %d).\n", GetLastError());
		ZeroMemory(&s, sizeof(s));
		return s;
	}
	return s;
}

/* Convert Simulink time (time_T) to PLCSim time, using the PLCSim base time */
static SYSTEMTIME ConvertSimulinkTimeToPLCSimTime(time_T simulinkTime)
{
	ULONGLONG plcsimBlockTime = (ULONGLONG)(simulinkTime * 10000000);
	ULONGLONG basePlcsimTimeULL = SystemTimeToULongLong(basePLCSimTime);
	return ULongLongToSystemTime(plcsimBlockTime + basePlcsimTimeULL);
}

/* Convert PLCSim time to SYSTEMTIME Simulink time (time_T), using the PLCSim base time */
static time_T ConvertPLCSimTimeToSimulinkTime(SYSTEMTIME plcsimTime)
{
	ULONGLONG plcsimTimeULL = SystemTimeToULongLong(plcsimTime);
	ULONGLONG basePlcsimTimeULL = SystemTimeToULongLong(basePLCSimTime);
	ULONGLONG plcsimBlockTime = plcsimTimeULL - basePlcsimTimeULL;
	return ((time_T)plcsimBlockTime) / 10000000;
}

/* Invert the byte order of a byte array, non-destructive */
inline static void InvertByteOrder(BYTE inbytes[], BYTE outbytes[], int_T numbytes)
{
	for (int_T b = 0; b < numbytes; ++b)
	{
		outbytes[b] = inbytes[numbytes - 1 - b];
	}
}

/* Invert the byte order of a byte array, in place */
inline static void InvertByteOrder(BYTE inoutbytes[], int_T numbytes)
{
	for (int_T b1 = 0; b1 < (numbytes / 2); ++b1)
	{
		int_T b2 = numbytes - 1 - b1;
		inoutbytes[b1] ^= inoutbytes[b2];
		inoutbytes[b2] ^= inoutbytes[b1];
		inoutbytes[b1] ^= inoutbytes[b2];
	}
}

/*** Behavior Functions ***/

/* Callback function for PLCSIM Advanced */
static void ConfigurationChanged(IInstance* in_Sender, ERuntimeErrorCode in_ErrorCode, SYSTEMTIME in_SystemTime, EInstanceConfigChanged in_InstanceConfigChanged, UINT32 in_Param1, UINT32 in_Param2, UINT32 in_Param3, UINT32 in_Param4)
{
	tags.invalidate();
}

#if SyncWithCallback
/* Callback function for end-of-cycle event from PLCSIM Advanced */
static void EndOfCycle(IInstance* in_Sender, ERuntimeErrorCode in_ErrorCode, SYSTEMTIME in_SystemTime, INT64 CycleTime_ns, INT64 CycleCount)
{
#if SyncWithSemaphore
	ReleaseSemaphore(Semaphore, 1, 0);
#endif
#if SyncWithFlag
	waiting = false;
#endif
}
#endif

#if SyncWithSemaphore
/* Initialize the local semaphore for synchronization with PLCSIM Advanced */
static bool InitializeSemaphore()
{
	if (Semaphore) return true;

	Semaphore = CreateSemaphore(0, 0, 1, 0);
	if (!Semaphore)
	{
		PrintFormattedError("Error creating semaphore.\n");
		srec = SREC_UNKNOWN_MESSAGE_TYPE;
		return false;
	}

	return true;
}
#endif

/* Shut down PLCSIM Advanced interface, disconnect from runtime manager and return to the initial system state */
static void Shutdown()
{
	if (PLCSimInstance != 0)
	{
		srec = DestroyInterface(PLCSimInstance);
		if (srec == SREC_OK) PLCSimInstance = 0;
		else PrintFormattedPLCSimError("Could not destroy instance interface.\n");
	}

	if (RemoteRuntimeManager != 0)
	{
		srec = DestroyInterface(RemoteRuntimeManager);
		if (srec == SREC_OK) RemoteRuntimeManager = 0;
		else PrintFormattedPLCSimError("Could not shutdown remote PLCSIM Advanced API.\n");
	}
	if (RuntimeManager != 0)
	{
		srec = ShutdownAndFreeApi(RuntimeManager);
		if (srec == SREC_OK) RuntimeManager = 0;
		else PrintFormattedPLCSimError("Could not shutdown PLCSIM Advanced API.\n");
	}

}

/* Loads and initializes the PLCSIM Advanced API DLL */
static bool LoadAndInitializeAPI()
{
	srec = InitializeApi(&RuntimeManager);
	if (srec != SREC_OK)
	{
		PrintFormattedPLCSimError("Could not initialize PLCSIM Advanced API.\n");
		Shutdown();
		return false;
	}

	return true;
}

/* Main startup procedure for the PLCSIM Advanced S-Function */
static bool Startup()
{
	if (RuntimeManager != 0) return true;
	if (Networking && RemoteRuntimeManager != 0) return true;


	if (!LoadAndInitializeAPI()) return false;

	if (Networking) {
		srec = RuntimeManager->RemoteConnect(IP, Port, &RemoteRuntimeManager);

		if (srec != SREC_OK) {

			PrintFormattedPLCSimError("Could not create RemoteRuntimeManager\n");
			Shutdown();
			return false;
		}
	}
#if SyncWithSemaphore
	if (!InitializeSemaphore()) return false;
#endif
	if (Networking) {
		srec = RemoteRuntimeManager->RegisterInstance(InstanceNameWS, &PLCSimInstance);
	}
	else {
		srec = RuntimeManager->RegisterInstance(InstanceNameWS, &PLCSimInstance);
	}
	if (srec == SREC_ALREADY_EXISTS)
	{
		tags.invalidate();

		if (Networking) {
			srec = RemoteRuntimeManager->CreateInterface(InstanceNameWS, &PLCSimInstance);
		}
		else
		{
			srec = RuntimeManager->CreateInterface(InstanceNameWS, &PLCSimInstance);
		}
		if (srec != SREC_OK)
		{
			PrintFormattedPLCSimError("Could not create Interface\n");
			Shutdown();
			return false;
		}
	}
	else if (srec != SREC_OK)
	{
		PrintFormattedPLCSimError("Could not register Instance\n");
		Shutdown();
		return false;
	}

#if 0
	srec = PLCSimInstance->SetStoragePath(InstanceNameWS);
	if (srec != SREC_OK)
	{
		PrintFormattedPLCSimError("Could not set StoragePath\n");
		Shutdown();
		return false;
	}
#endif

#if SyncWithCallback
	PLCSimInstance->RegisterOnSyncPointReachedCallback(EndOfCycle);
#endif
#if SyncWithEvent
	PLCSimInstance->RegisterOnSyncPointReachedEvent();
#endif

	PLCSimInstance->RegisterOnConfigurationChangedEvent();
	PLCSimInstance->RegisterOnConfigurationChangedCallback(ConfigurationChanged);

	srec = PLCSimInstance->PowerOn(60000);
	if (srec == SREC_WARNING_TRIAL_MODE_ACTIVE)
	{
		PrintFormattedMessage("No license available. The PLCSIM Advanced instance is running for one hour in trial mode.\n");
	}
	else if (srec != SREC_OK && srec != SREC_WARNING_ALREADY_EXISTS && srec != SREC_STORAGE_PATH_ALREADY_IN_USE)
	{
		PrintFormattedPLCSimError("Could not PowerOn");
		return false;
	}

	return true;
}

/* Write block inputs to PLCSIM Advanced */
static void ReadInputs(SimStruct *S)
{
	if (PLCSimInstance == 0) return;
	int_T numInputPorts = ssGetNumInputPorts(S);

	int realInputCounter = 0;
	for (int_T i = 0; i < numInputPorts; i++)
	{
		if (i < tags.NumInputTags() && tags.InputArea(i) == EArea::SRA_INPUT)
		{
			const BYTE *input = (const BYTE*)ssGetInputPortSignal(S, i);
			if (tags.InputDataType(i) == SRDT_BOOL)
			{
				srec = PLCSimInstance->WriteBit(SRA_INPUT, tags.InputOffset(i), tags.InputBit(i), (*input) == 0 ? false : true);
				if (srec != SREC_OK)
				{
					PrintFormattedPLCSimError("WriteBit\n");
					return;
				}
			}
			else
			{
				memcpy(IOBuffer, input, tags.InputSize(i));
				InvertByteOrder(IOBuffer, tags.InputSize(i));
				UINT32 bytesWritten;
				srec = PLCSimInstance->WriteBytes(SRA_INPUT, tags.InputOffset(i), tags.InputSize(i), &bytesWritten, IOBuffer);
				if (srec != SREC_OK)
				{
					PrintFormattedPLCSimError("WriteBytes\n");
					return;
				}
			}
			realInputCounter++;
		}
	}

	for (int_T i = 0; i < numInputPorts; i++) {

		DTypeId type = ssGetInputPortDataType(S, i + realInputCounter);
		if (tags.DatablockInputArea(i) == EArea::SRA_DATABLOCK)
		{
			const UINT64 *input = (const UINT64*)ssGetInputPortSignal(S, i + realInputCounter);

			switch (type) {
			case SS_DOUBLE:
				memcpy(&inputDataValueByName[i].DataValue.Value.UInt64, input, sizeof(outputDataValueByName[i].DataValue.Value.UInt64));
				break;
			case SS_SINGLE:
			case SS_INT32:
			case SS_UINT32:
				memcpy(&inputDataValueByName[i].DataValue.Value.UInt32, input, sizeof(outputDataValueByName[i].DataValue.Value.UInt32));
				break;
			case SS_INT16:
			case SS_UINT16:
				memcpy(&inputDataValueByName[i].DataValue.Value.UInt16, input, sizeof(outputDataValueByName[i].DataValue.Value.UInt16));
				break;
			case SS_INT8:
			case SS_UINT8:
				memcpy(&inputDataValueByName[i].DataValue.Value.UInt8, input, sizeof(outputDataValueByName[i].DataValue.Value.UInt8));
				break;
			case SS_BOOLEAN:
				memcpy(&inputDataValueByName[i].DataValue.Value.Bool, input, sizeof(outputDataValueByName[i].DataValue.Value.Bool));
				break;
			default:
				PrintFormattedMessage("Input has unsupported datatype\n");
			}
			EPrimitiveDataType primitivePlcDataType = tags.DatablockInputPrimitiveDataType(i);
			memcpy(&inputDataValueByName[i].DataValue.Type, &primitivePlcDataType, sizeof(primitivePlcDataType));
		}
	}

	srec = PLCSimInstance->WriteSignals(inputDataValueByName, (UINT32)tags.NumDatablockInputTags());

}

/* Read block outputs from PLCSIM Advanced */
static void WriteOutputs(SimStruct *S)
{
	int_T numOutputPorts = ssGetNumOutputPorts(S);

	//read all datablock variables
	srec = PLCSimInstance->ReadSignals(outputDataValueByName, (UINT32)tags.NumDatablockOutputTags());

	if (srec != SREC_OK)
	{
		PrintFormattedPLCSimError("ReadSignals\n");
	}

	int realOutputCounter = 0;
	for (int_T i = 0; i < numOutputPorts; i++)
	{
		BYTE *output = (BYTE*)ssGetOutputPortSignal(S, i);
		if (i < tags.NumOutputTags() && tags.OutputArea(i) == EArea::SRA_OUTPUT)
		{
			if (tags.OutputDataType(i) == SRDT_BOOL)
			{
				srec = PLCSimInstance->ReadBit(SRA_OUTPUT, tags.OutputOffset(i), tags.OutputBit(i), (bool*)output);
				if (srec != SREC_OK)
				{
					PrintFormattedPLCSimError("ReadBit\n");
					return;
				}
			}
			else
			{
				UINT32 bytesRead;
				srec = PLCSimInstance->ReadBytes(SRA_OUTPUT, tags.OutputOffset(i), tags.OutputSize(i), &bytesRead, IOBuffer);
				if (srec != SREC_OK)
				{
					PrintFormattedPLCSimError("ReadBytes\n");
					return;
				}
				InvertByteOrder(IOBuffer, tags.OutputSize(i));
				memcpy(output, IOBuffer, tags.OutputSize(i));
			}
			realOutputCounter++;
		}
	}

	for (int_T i = 0; i < numOutputPorts; i++)
	{
		DTypeId type = ssGetOutputPortDataType(S, i + realOutputCounter);
		if (tags.DatablockOutputArea(i) == EArea::SRA_DATABLOCK)
		{
			UINT64 *output = (UINT64*)ssGetOutputPortSignal(S, i + realOutputCounter);

			if (outputDataValueByName[i].ErrorCode == SREC_OK) {
				switch (type) {
				case SS_DOUBLE:
					memcpy(output, &outputDataValueByName[i].DataValue.Value.UInt64, sizeof(outputDataValueByName[i].DataValue.Value.UInt64));
					break;
				case SS_SINGLE:
				case SS_INT32:
				case SS_UINT32:
					memcpy(output, &outputDataValueByName[i].DataValue.Value.UInt32, sizeof(outputDataValueByName[i].DataValue.Value.UInt32));
					break;
				case SS_INT16:
				case SS_UINT16:
					memcpy(output, &outputDataValueByName[i].DataValue.Value.UInt16, sizeof(outputDataValueByName[i].DataValue.Value.UInt16));
					break;
				case SS_INT8:
				case SS_UINT8:
					memcpy(output, &outputDataValueByName[i].DataValue.Value.UInt8, sizeof(outputDataValueByName[i].DataValue.Value.UInt8));
					break;
				case SS_BOOLEAN:
					memcpy(output, &outputDataValueByName[i].DataValue.Value.Bool, sizeof(outputDataValueByName[i].DataValue.Value.Bool));
					break;
				default:
					PrintFormattedMessage("Output has unsupported datatype\n");
				}
			}
		}
	}
}

/* Wait for the end of the PLC cycle. */
static bool WaitForEndOfCycle(int pipID)
{
#if SyncWithSemaphore
	WaitForSingleObject(Semaphore, 10 * 1000);
	return true;
#endif

#if SyncWithFlag
	waiting = true;
	while (waiting) Sleep(10);
	return true;
#endif

#if SyncWithEvent
	// Wait up to 10 seconds for the end of the cycle.
	SOnSyncPointReachedResult res = PLCSimInstance->WaitForOnSyncPointReachedEvent(10000);
	if (res.ErrorCode == SREC_TIMEOUT)
	{
		PrintFormattedError("Timeout ocurred while waiting for end of cycle (pip = %d) from PLCSIM Advanced.\n",pipID);
		return true;
	}

	if (res.PipId == pipID) {
		return true;
	}
	else
	{
		return false;
	}
#endif
}

/* Execute a simulation step of the PLC emulation, using time synchronization with the Simulink time. */
static void ExecuteSynchronizedSimulationStep(SimStruct *S)
{
	time_T currentSimulinkTime = ssGetT(S);
	time_T currentPLCSimTime = ConvertPLCSimTimeToSimulinkTime(PLCSimInstance->GetSystemTime());

	//PrintFormattedMessage("ExecuteSynchronizedSimulationStep currentPLCSimTime = %ld, currentSimulinkTime = %ld.\n");

	// Read the current inputs from Simulink if the PLCSim time is at or beyond the Simulink time. 
	if (currentPLCSimTime >= currentSimulinkTime)
	{
		ReadInputs(S);
	}

	// Execute PLCSim if the PLCSim time is before or at the Simulink time. The PLCSim inputs have already been
	// updated in this same simulation step or in a previous simulation step.
	if (currentPLCSimTime <= currentSimulinkTime)
	{
#if ExecuteRunNextCycleLoop
		// Execute PLC cycles until the current simulation time is reached.
		do
		{
			// First, write the outputs from the previous cycle. These values will be the result of the 
			// current simulation step, if this is the last iteration of the while loop.
			WriteOutputs(S);

			//look for the next syncpoint with corresponding pip id
			do 
			{
				// Execute the next PLC cycle.
				srec = PLCSimInstance->RunToNextSyncPoint();
				if (srec != SREC_OK)
				{
					PrintFormattedPLCSimError("RunNextCycle\n");
					return;
				}
				//break if WaitForEndOfCycle with corresponding pip did not return true after 1s
				if ((ConvertPLCSimTimeToSimulinkTime(PLCSimInstance->GetSystemTime()) - currentPLCSimTime) > 1) {
					PrintFormattedError("Timeout waiting for syncpoint pip %d", pip);
					break;
				}

			} while (!WaitForEndOfCycle(pip));

			// Get the new PLCSim time
			currentPLCSimTime = ConvertPLCSimTimeToSimulinkTime(PLCSimInstance->GetSystemTime());

		} while (currentPLCSimTime <= currentSimulinkTime);
#endif

		// Now read the current inputs from Simulink, because the PLCSim time is beyond the Simulink time.
		// These inputs will be used in the following simulation step.
		ReadInputs(S);
	}
}

/*** Callback functions for Simulink ***/

void mdlCheckParameters(SimStruct *S)
{
	// InstanceName
	const mxArray *instanceNameParam = ssGetSFcnParam(S, ParameterIndex_InstanceName);
	DTypeId instanceNameType = ssGetDTypeIdFromMxArray(instanceNameParam);
	size_t instanceNameLength = mxGetNumberOfElements(instanceNameParam);
	if (instanceNameType != INVALID_DTYPE_ID || instanceNameLength > maxInstanceNameLength)
	{
		ssSetErrorStatus(S, "Invalid parameter value for InstanceName");
		return;
	}
	mxGetString(instanceNameParam, InstanceName, maxInstanceNameLength + 1);

	PrintFormattedMessage("InstanceName %s\n", InstanceName);
	size_t convertedChars;
	mbstowcs_s(&convertedChars, InstanceNameWS, maxInstanceNameLength + 1, InstanceName, _TRUNCATE);

	// InputPortCount
	const mxArray *inputPortCountParam = ssGetSFcnParam(S, ParameterIndex_InputPortCount);
	DTypeId inputPortCountType = ssGetDTypeIdFromMxArray(inputPortCountParam);
	size_t inputPortCountLength = mxGetNumberOfElements(inputPortCountParam);
	if (inputPortCountType != SS_DOUBLE || inputPortCountLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for InputPortCount");
		return;
	}
	InputPortCount = (int)*(real_T*)mxGetData(inputPortCountParam);

	// OutputPortCount
	const mxArray *outputPortCountParam = ssGetSFcnParam(S, ParameterIndex_OutputPortCount);
	DTypeId outputPortCountType = ssGetDTypeIdFromMxArray(outputPortCountParam);
	size_t outputPortCountLength = mxGetNumberOfElements(outputPortCountParam);
	if (outputPortCountType != SS_DOUBLE || outputPortCountLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for OutputPortCount");
		return;
	}
	OutputPortCount = (int)*(real_T*)mxGetData(outputPortCountParam);

	// ScaleFactor
	const mxArray *scaleFactorParam = ssGetSFcnParam(S, ParameterIndex_ScaleFactor);
	DTypeId scaleFactorType = ssGetDTypeIdFromMxArray(scaleFactorParam);
	size_t scaleFactorLength = mxGetNumberOfElements(scaleFactorParam);
	if (scaleFactorType != SS_DOUBLE || scaleFactorLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for ScaleFactor");
		return;
	}
	ScaleFactor = *(real_T*)mxGetData(scaleFactorParam);

	// Synchronization
	const mxArray *synchronizationParam = ssGetSFcnParam(S, ParameterIndex_Synchronization);
	DTypeId synchronizationType = ssGetDTypeIdFromMxArray(synchronizationParam);
	size_t synchronizationLength = mxGetNumberOfElements(synchronizationParam);
	if (synchronizationType != SS_DOUBLE || synchronizationLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for Synchronization");
		return;
	}
	Synchronization = (*(real_T*)mxGetData(synchronizationParam) != 0);

	// Networking
	const mxArray *networkingParam = ssGetSFcnParam(S, ParameterIndex_Networking);
	DTypeId networkingType = ssGetDTypeIdFromMxArray(networkingParam);
	size_t networkingLength = mxGetNumberOfElements(networkingParam);
	if (networkingType != SS_DOUBLE || networkingLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for Networking");
		return;
	}
	Networking = (*(real_T*)mxGetData(networkingParam) != 0);

	// IP
	const mxArray *ipParam = ssGetSFcnParam(S, ParameterIndex_IP);
	DTypeId ipType = ssGetDTypeIdFromMxArray(ipParam);
	size_t ipLength = mxGetNumberOfElements(ipParam);

	if (ipType != INVALID_DTYPE_ID || ipLength > maxIPLength)
	{
		ssSetErrorStatus(S, "Invalid parameter value for IP");
		return;
	}

	mxGetString(ipParam, StringIP, maxIPLength + 1);

	//check for correct IP format
	int pointCounter = 0;
	char* temp = strchr(StringIP, '.');
	while (temp != NULL) {
		pointCounter++;
		temp = strchr(temp + 1, '.');
	}

	if (strncmp(StringIP, "localhost", maxIPLength + 1) == 0) {
		IP.IPs[3] = 127;
		IP.IPs[2] = 0;
		IP.IPs[1] = 0;
		IP.IPs[0] = 1;
	}
	else if (pointCounter == 3) {
		temp = strtok(StringIP, ".");
		IP.IPs[3] = atoi(temp);
		temp = strtok(NULL, ".");
		IP.IPs[2] = atoi(temp);
		temp = strtok(NULL, ".");
		IP.IPs[1] = atoi(temp);
		temp = strtok(NULL, ".");
		IP.IPs[0] = atoi(temp);
	}
	else {
		ssSetErrorStatus(S, "Invalid parameter value for IP");
		return;
	}

	PrintFormattedMessage("IP %d.%d.%d.%d\n", IP.IPs[3], IP.IPs[2], IP.IPs[1], IP.IPs[0]);

	// Port
	const mxArray *portParam = ssGetSFcnParam(S, ParameterIndex_Port);
	DTypeId portType = ssGetDTypeIdFromMxArray(portParam);
	size_t portLength = mxGetNumberOfElements(portParam);
	if (portType != SS_DOUBLE || portLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for Port");
		return;
	}
	Port = (UINT16)*(real_T*)mxGetData(portParam);

	// outputVariables
	const mxArray *outputVariablesParam = ssGetSFcnParam(S, ParameterIndex_OutputVariables);
	DTypeId outputVariablesType = ssGetDTypeIdFromMxArray(outputVariablesParam);
	size_t outputVariablesLength = mxGetNumberOfElements(outputVariablesParam);
	if (outputVariablesType != INVALID_DTYPE_ID || outputVariablesLength > maxVariablesLength)
	{
		ssSetErrorStatus(S, "Invalid parameter value for outputVariables");
		return;
	}

	mxGetString(outputVariablesParam, StringOutputVariables, maxVariablesLength + 1);
	if (StringOutputVariables[0] != 0) {
		outputVariableCounter = 0;
		temp = strchr(StringOutputVariables, ';');
		while (temp != NULL) {
			outputVariableCounter++;
			temp = strchr(temp + 1, ';');
		}
		if (sizeof(StringOutputVariables) != 0) {
			//Add the last variable which is not followed by a ";"
			outputVariableCounter++;
		}

		if (outputVariableCounter != 0) {
			outputVariables.clear();
			outputVariables.push_back(strtok(StringOutputVariables, ";"));
			PrintFormattedMessage("Variable 0: %s\n", outputVariables.at(0).c_str());
			for (int i = 1; i < outputVariableCounter; i++) {
				outputVariables.push_back(strtok(NULL, ";"));
				PrintFormattedMessage("Variable %d: %s\n", i, outputVariables.at(i).c_str());
			}
		}
	}
	else {
		outputVariableCounter = 0;
		PrintFormattedMessage("The output variable string is empty\n");
	}

	// inputVariables
	const mxArray *inputVariablesParam = ssGetSFcnParam(S, ParameterIndex_InputVariables);
	DTypeId inputVariablesType = ssGetDTypeIdFromMxArray(inputVariablesParam);
	size_t inputVariablesLength = mxGetNumberOfElements(inputVariablesParam);
	if (inputVariablesType != INVALID_DTYPE_ID || inputVariablesLength > maxVariablesLength)
	{
		ssSetErrorStatus(S, "Invalid parameter value for inputVariables\n");
		//return;
	}

	mxGetString(inputVariablesParam, StringInputVariables, maxVariablesLength + 1);
	if (StringInputVariables[0] != 0) {
		inputVariableCounter = 0;
		temp = strchr(StringInputVariables, ';');
		while (temp != NULL) {
			inputVariableCounter++;
			temp = strchr(temp + 1, ';');
		}
		if (sizeof(StringInputVariables) != 0) {
			//Add the last variable which is not followed by a ";"
			inputVariableCounter++;
		}

		if (inputVariableCounter != 0) {
			inputVariables.clear();
			inputVariables.push_back(strtok(StringInputVariables, ";"));
			PrintFormattedMessage("Variable 0: %s\n", inputVariables.at(0).c_str());
			for (int i = 1; i < inputVariableCounter; i++) {
				inputVariables.push_back(strtok(NULL, ";"));
				PrintFormattedMessage("Variable %d: %s\n", i, inputVariables.at(i).c_str());
			}
		}
	}
	else {
		inputVariableCounter = 0;
		PrintFormattedMessage("The input variable string is empty\n");
	}

	// PIP
	const mxArray *pipParam = ssGetSFcnParam(S, ParameterIndex_PIP);
	DTypeId pipType = ssGetDTypeIdFromMxArray(pipParam);
	size_t pipLength = mxGetNumberOfElements(pipParam);
	if (pipType != SS_DOUBLE || pipLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for PIP\n");
		return;
	}
	pip = (int)*(real_T*)mxGetData(pipParam);

	// SampleTime
	const mxArray *sampleParam = ssGetSFcnParam(S, ParameterIndex_SampleTime);
	DTypeId sampleType = ssGetDTypeIdFromMxArray(sampleParam);
	size_t sampleLength = mxGetNumberOfElements(sampleParam);
	if (sampleType != SS_DOUBLE || sampleLength != 1)
	{
		ssSetErrorStatus(S, "Invalid parameter value for PIP\n");
		return;
	}
	sampleTime = (double)*(real_T*)mxGetData(sampleParam);
}

void mdlInitializeSizes(SimStruct *S)
{
	PrintFormattedMessage("mdlInitializeSizes\n");

	ssSetOptions(S, SS_OPTION_CALL_TERMINATE_ON_EXIT);

	BlockPath = ssGetPath(S);

	ssSetNumSFcnParams(S, ParameterCount);  /* Number of expected parameters */

	if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S))
	{
		mdlCheckParameters(S);
		if (ssGetErrorStatus(S) != 0) return;
	}
	else
	{
		PrintFormattedError("Parameter mismatch\n");
		return; /* Parameter mismatch reported by the Simulink engine */
	}

	if (!Startup())
	{
		PrintFormattedError("Startup\n");
		return;
	}

	tags.UpdateTagMap(PLCSimInstance);

	int_T numInputPorts = (InputPortCount == -1) ? (int_T)(tags.NumInputTags() + tags.NumDatablockInputTags()) : InputPortCount;
	int_T numOutputPorts = (OutputPortCount == -1) ? (int_T)(tags.NumOutputTags() + tags.NumDatablockOutputTags()) : OutputPortCount;

	if (!ssSetNumInputPorts(S, numInputPorts))
	{
		PrintFormattedError("SetNumInputPorts\n");
		return;
	}

	int_T i = 0;
	for (i = 0; i < min(numInputPorts, tags.NumInputTags()); ++i)
	{
		ssSetInputPortWidth(S, i, 1);
		ssSetInputPortDirectFeedThrough(S, i, 1);
		ssSetInputPortDataType(S, i, tags.InputSSDataType(i));
		ssSetInputPortRequiredContiguous(S, i, 1);
	}
	for (int_T j = 0; j < min(numInputPorts, tags.NumDatablockInputTags()); ++j)
	{
		ssSetInputPortWidth(S, i + j, 1);
		ssSetInputPortDirectFeedThrough(S, i + j, 1);
		ssSetInputPortDataType(S, i + j, tags.DatablockInputSSDataType(j));
		ssSetInputPortRequiredContiguous(S, i + j, 1);
	}

	if (!ssSetNumOutputPorts(S, numOutputPorts))
	{
		PrintFormattedError("SetNumOutputPorts\n");
		return;
	}

	i = 0;
	for (i = 0; i < min(numOutputPorts, tags.NumOutputTags()); ++i)
	{
		ssSetOutputPortWidth(S, i, 1);
		ssSetOutputPortDataType(S, i, tags.OutputSSDataType(i));
	}
	for (int_T j = 0; j < min(numOutputPorts, tags.NumDatablockOutputTags()); ++j)
	{
		ssSetOutputPortWidth(S, i + j, 1);
		ssSetOutputPortDataType(S, i + j, tags.DatablockOutputSSDataType(j));
	}
	ssSetNumSampleTimes(S, 1);
}

void mdlInitializeSampleTimes(SimStruct *S)
{
	PrintFormattedMessage("mdlInitializeSampleTimes\n");

	// Let Simulink be the time master. Execute as many cycles in a simulation step as necessary.	
	if (sampleTime < 0) {
		ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
		PrintFormattedMessage("SampleTime = INHERITED_SAMPLE_TIME");
	}
	else {
		ssSetSampleTime(S, 0, (time_T)sampleTime);
		PrintFormattedMessage("SampleTime = %f",sampleTime);
	}
	ssSetOffsetTime(S, 0, 0.0);

	ssSetModelReferenceSampleTimeDefaultInheritance(S);

	if (PLCSimInstance == 0)
	{
		PrintFormattedError("PLCSimInstance is null\n");
		return;
	}

	// Set time in PLCSim from simulation start time of Simulink
	time_T simulinkStartTime = ssGetTStart(S);
	PLCSimInstance->SetSystemTime(ConvertSimulinkTimeToPLCSimTime(simulinkStartTime));
}

void mdlStart(SimStruct *S)
{
#if ExecuteRunNextCycleLoop
	PLCSimInstance->SetOperatingMode(SROM_SINGLE_STEP_CP);
#endif

	srec = PLCSimInstance->SetScaleFactor(ScaleFactor);
	if (srec != SREC_OK)
	{
		PrintFormattedPLCSimError("SetScaleFactor\n");
		return;
	}

	srec = PLCSimInstance->Run(60000);
	if (srec != SREC_OK)
	{
		PrintFormattedPLCSimError("Run\n");
		return;
	}
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
	if (PLCSimInstance == 0)
	{
		PrintFormattedError("PLCSimInstance is null\n");
		return;
	}

	if (!tags.TagMapValid())
	{
		// A download in RUN has ocurred, we shouldn't continue with the simulation
		// because the I/O addresses may have changed.
		PrintFormattedMessage("Configuration changed in PLCSIM Advanced during the simulation. Please restart the simulation.\n");
		return;
	}

	if (Synchronization)
	{
		ExecuteSynchronizedSimulationStep(S);
	}
	else
	{
		pip = 0;
		// Time synchronization is disabled. Run exactly one PLC cycle for every simulation step.
		// The time in Simulink and in PLCSIM Advanced will deviate arbitrarily.

		// First, write the outputs from the previous cycle. These values will be the result of the 
		// current simulation step.
		WriteOutputs(S);

		// Now read the current inputs from Simulink, to be used for the next PLC cycle.
		ReadInputs(S);

		// Execute the next PLC cycle.
		srec = PLCSimInstance->RunToNextSyncPoint();
		if (srec != SREC_OK)
		{
			PrintFormattedPLCSimError("RunToNextSyncPoint\n");
			return;
		}

		WaitForEndOfCycle(pip);
	}
}

static void mdlTerminate(SimStruct *S)
{
	if (PLCSimInstance == 0) return;

	PLCSimInstance->SetOperatingMode(SROM_DEFAULT);

	srec = PLCSimInstance->Stop();
	if (srec != SREC_OK)
	{
		PrintFormattedPLCSimError("Stop\n");
		return;
	}

#if ShutdownWhenTerminating
	Shutdown();
#endif

	BlockPath = 0;
}

#include "simulink.c"

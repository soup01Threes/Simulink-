% Build script for PLCSimAdvancedSFunction

mex -g -v PLCSimAdvancedSFunction.cpp




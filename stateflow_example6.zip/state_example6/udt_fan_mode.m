classdef(Enumeration) udt_fan_mode< Simulink.IntEnumType
    enumeration
        Off(0)
        Lo(1)
        Hi(2)
    end
end

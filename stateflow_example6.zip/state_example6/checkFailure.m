function status=checkFailure(Settings,Sensor)

Fan=0;
Fault=0;

if Settings ==1
    Fan=1;
end

if Fan==1 && Sensor == 1
    Fault=1;
end

status=Fault;